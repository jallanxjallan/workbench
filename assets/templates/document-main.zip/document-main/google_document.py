
from  attr import define, field, Factory
from google.oauth2.credentials import Credentials
from google.oauth2 import service_account
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build

# If modifying these scopes, delete the token.json file.
SCOPES = ['https://www.googleapis.com/auth/documents', 'https://www.googleapis.com/auth/drive']

token_path = '/home/jeremy/Python3.12Env/document/jallanjallan-24c582b1ad53.json'

def get_docs_service():
    """Create and return a Google Docs API service object."""
    creds = service_account.Credentials.from_service_account_file(token_path)
    return build('docs', 'v1', credentials=creds)

@define
class GoogleDocManager:
    service = field(default=Factory(get_docs_service))
    document_id = field(default=None)

    def read_document(self):
        """Read text from a Google Docs file."""
        doc = self.service.documents().get(documentId=self.document_id).execute()
        content = ""
        for element in doc.get('body', {}).get('content', []):
            if 'paragraph' in element:
                for text_run in element['paragraph'].get('elements', []):
                    if 'textRun' in text_run:
                        content += text_run['textRun'].get('content', '')
        
        # print("Document Content:")
        # print(content)
        return content

'''
**OAuth 2.0** would be the most suitable option for your scenario. Here's why:

* **Security:** OAuth 2.0 provides a more secure way to authenticate your script with your Google Workspace account compared to API keys.
* **User consent:** As the only user, you can grant explicit consent for your script to access your Drive.
* **Flexibility:** OAuth 2.0 allows for more granular permission control and can be used with other Google APIs if needed.

**Here's a simplified outline of the steps involved:**

1. **Create an OAuth 2.0 client ID:** In the Google Cloud Console, create a new OAuth 2.0 client ID.
2. **Grant necessary permissions:** Grant the client ID the "Drive" API scope with appropriate permissions.
3. **Implement OAuth 2.0 flow:** Use the `google-auth-oauthlib` library in your Python script to implement the OAuth 2.0 flow. This typically involves:
   - Authorizing the script to access your Drive account.
   - Obtaining an access token.
   - Using the access token to make API calls to the Drive service.

**Example:**

```python
import os
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build

# Replace with your client ID and client secret
client_id = 'your_client_id'
client_secret = 'your_client_secret'

# Create credentials object
creds = Credentials.from_client_id_and_secret(client_id, client_secret)

# Refresh credentials if needed
if not creds.valid:
    if creds.expired and creds.refresh_token:
        creds.refresh(Request())

# Build the Drive service
service = build('drive', 'v3', credentials=creds)

# Upload a file
file_metadata = {'name': 'your_file.txt'}
media = MediaFileUpload('path/to/your/file.txt', mimetype='text/plain')
file = service.files().create(body=file_metadata, media_body=media, fields='id').execute()
print('File ID: %s' % file.get('id'))
```

By following these steps, you can securely and efficiently grant your Python script permission to upload documents to your Google Workspace.



'''


# def get_document_id(self, folder_name, doc_title):
#     """
#     Fetch the Google Document ID based on the folder name and document title.

#     Args:
#         credentials_path (str): Path to the service account JSON credentials file.
#         folder_name (str): The name of the Google Drive folder to search in.
#         doc_title (str): The title of the Google Doc to search for.

#     Returns:
#         str: The ID of the Google Doc if found, otherwise None.
#     """
#     try:
#         # Load the credentials from the service account JSON file
#         creds = Credentials.from_service_account_file(s)
        
#         # Initialize the Drive API client
#         drive_service = build('drive', 'v3', credentials=creds)
        
#         # Step 1: Find the folder ID by searching with the folder name
#         query = f"name = '{folder_name}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false"
#         results = drive_service.files().list(q=query, fields="files(id, name)").execute()
        
#         folder_files = results.get('files', [])
        
#         if not folder_files:
#             print(f"Folder '{folder_name}' not found.")
#             return None
        
#         # Assuming the first match is the desired folder
#         folder_id = folder_files[0]['id']
        
#         # Step 2: Find the Google Doc within the specified folder
#         query = f"'{folder_id}' in parents and name = '{doc_title}' and mimeType = 'application/vnd.google-apps.document' and trashed = false"
#         results = drive_service.files().list(q=query, fields="files(id, name)").execute()
        
#         doc_files = results.get('files', [])
        
#         if not doc_files:
#             print(f"Document '{doc_title}' not found in folder '{folder_name}'.")
#             return None
        
#         # Return the ID of the first matched document
#         self.document_id = doc_files[0]['id']
    
#     except Exception as error:
#         print(f"An error occurred: {error}")
#         return None

    
    
    def create_document(self, title):
        """Create a new Google Docs file and return the document ID."""
        document = self.service.documents().create(body={"title": title}).execute()
        document_id = document.get('documentId')
        print(f"Created Google Doc with ID: {document_id}")
        return document_id

    def write_to_document(self, document_id, text):
        """Write text to a Google Docs file."""
        service = self.get_docs_service()
        requests = [
            {
                'insertText': {
                    'location': {
                        'index': 1,  # Start writing after the title
                    },
                    'text': text
                }
            }
        ]
        result = service.documents().batchUpdate(documentId=document_id, body={'requests': requests}).execute()
        print(f"Document updated: {result}")

    


