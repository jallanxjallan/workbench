#!/home/jeremy/Python3.12Env/bin/python
from __future__ import annotations
from pydantic import BaseModel, Field, field_validator, model_validator
from pathlib import Path
from typing import Optional, Dict, Any, Union
import frontmatter
import json
import re
import hashlib


class Document(BaseModel):
    """Ephemeral wrapper for scene/note files with metadata and content."""

    content: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)
    filepath: Optional[Path] = None
    sections: Dict[str, str] = Field(default_factory=dict)

    # ----------------------------
    # Validators
    # ----------------------------

    @field_validator("content", mode="before")
    @classmethod
    def join_list_or_gen(cls, v):
        """Normalize lists, generators, and simple values into strings."""
        if v is None:
            return None
        if isinstance(v, (int, float)):
            return str(v)
        if isinstance(v, (list, tuple)):
            return "\n\n".join(map(str, v))
        # Handle generators
        if hasattr(v, "__iter__") and not isinstance(v, (str, bytes, dict)):
            return "\n\n".join(map(str, v))
        return v


    @field_validator("metadata", mode="before")
    @classmethod
    def ensure_dict(cls, v):
        if v is None:
            return {}
        if isinstance(v, str):
            try:
                return json.loads(v)
            except Exception:
                return {"raw": v}
        if isinstance(v, dict):
            return v
        return dict(v)

    @field_validator("filepath", mode="before")
    @classmethod
    def ensure_path(cls, v):
        if v is None or isinstance(v, Path):
            return v
        return Path(v)

    @model_validator(mode="after")
    def normalize_sections_and_id(self) -> "VaultDocument":
        """Parse fenced sections and auto-generate slug + uid if missing."""
        if self.content:
            self.sections = self.parse_sections(self.content)

        if self.filepath:
            folder = self.filepath.parent.name
            stem = self.filepath.stem
            base = f"{folder}:{stem}"

            # Human-readable slug
            if "slug" not in self.metadata:
                self.metadata["slug"] = base

            # Stable UID (hash of slug)
            if "uid" not in self.metadata:
                uid = hashlib.sha1(base.encode("utf-8")).hexdigest()[:12]
                self.metadata["uid"] = uid

        return self

    # ----------------------------
    # Attribute-style metadata
    # ----------------------------

    def __getattr__(self, name: str) -> Any:
        if name in self.metadata:
            return self.metadata[name]
        raise AttributeError(f"{name} not found in document or metadata")

    def __setattr__(self, name: str, value: Any):
        # First priority: known fields
        if name in self.model_fields:
            super().__setattr__(name, value)
        else:
            # Fallback: treat as metadata field
            self.metadata[name] = value

    # ----------------------------
    # File I/O
    # ----------------------------

    @classmethod
    def read_file(cls, path: Union[str, Path]) -> "VaultDocument":
        path = Path(path)
        text = path.read_text(encoding="utf-8")

        if path.suffix in {".md", ".markdown"}:
            fm = frontmatter.loads(text)
            return cls(content=fm.content, metadata=fm.metadata, filepath=path)
        elif path.suffix == ".json":
            data = json.loads(text)
            return cls(**data, filepath=path)
        else:
            return cls(content=text, filepath=path)

    def write_file(self, path: Optional[Union[str, Path]] = None, fmt: Optional[str] = None):
        path = Path(path) if path else self.filepath
        if not path:
            raise ValueError("No filepath provided for writing.")

        fmt = fmt or path.suffix.lstrip(".")
        if fmt in {"md", "markdown"}:
            post = frontmatter.Post(self.content or "", **self.metadata)
            path.write_text(frontmatter.dumps(post), encoding="utf-8")
        elif fmt == "json":
            data = self.model_dump()
            path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        else:
            path.write_text(self.content or "", encoding="utf-8")

        self.filepath = path

    # ----------------------------
    # Section Parsing / Writing
    # ----------------------------

    @staticmethod
    def parse_sections(text: str) -> Dict[str, str]:
        pattern = re.compile(r"```(\w+)\n(.*?)```", re.DOTALL)
        return {m.group(1): m.group(2).strip() for m in pattern.finditer(text)}

    def get_section(self, name: str) -> Optional[str]:
        return self.sections.get(name)

    def set_section(self, name: str, text: str):
        self.sections[name] = text
        self._rebuild_content_from_sections()

    def _rebuild_content_from_sections(self):
        parts = []
        free_text = self.content or ""
        if free_text.strip() and not self.sections:
            self.content = free_text
            return
        for k, v in self.sections.items():
            parts.append(f"```{k}\n{v}\n```")
        self.content = "\n\n".join(parts)

    # ----------------------------
    # Utilities
    # ----------------------------

    def get_prompt(self) -> str:
        """Return the text after the final horizontal rule ('---'), or full content if no rule."""
        content = self.content or ""
        parts = content.strip().split("\n---\n")
        return parts[-1].strip() if parts else ""
    
    def append_results(self, result: str):
        """Append a horizontal rule and the result text to the end of the content."""
        base = (self.content or "").rstrip()
        self.content = f"{base}\n\n---\n{result.strip()}"
        self.sections = self.parse_sections(self.content)

    def append_text(self, new_text: str):
        """Appends text without the horizontal rule"""
        self.content = (self.content or "").rstrip() + "\n\n" + new_text
        self.sections = self.parse_sections(self.content)

    def word_count(self):
        return len(re.findall(r"\b\w+\b", self.content or ""))

    def summary(self, n: int = 20) -> str:
        words = re.findall(r"\b\w+\b", self.content or "")
        return " ".join(words[:n]) + ("..." if len(words) > n else "")

    def to_json(self) -> str:
        return json.dumps(self.model_dump(), ensure_ascii=False, indent=2)


