#!/home/jeremy/Python3.10Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com> 

from document import Document 
from pathlib import Path 
import pandas as pd
from utility import snake_case

def parse_doc(filepath):
    try:
        doc = Document.read_file(filepath) 
    except Exception as e:
        print(f'{e} with {filepath}') 
    return {**{'filepath':doc.filepath}, **doc.metadata}

def document_index(folder):
    base_dir = Path(folder) 
    if not base_dir.is_dir():
        raise ValueError(f'{folder} is not a folder') 
    df = pd.DataFrame([parse_doc(fp) for fp in base_dir.glob('**/*.md') if fp.suffix == '.md'])
    return df.dropna(subset='identifier').set_index('identifier')
        