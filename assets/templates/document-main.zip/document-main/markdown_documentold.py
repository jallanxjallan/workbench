#!/home/jeremy/Python3.12Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>


from typing import Optional
import attr
from attr import define, field
from attrs.converters import optional
from pathlib import Path
from utility import title_case
import frontmatter
import re


@define()
class Document():
    content  = field(default=None, converter=optional(lambda x: '\n\n'.join(x) if isinstance(x, list) else str(x)))
    metadata = field(default=None, converter=optional(lambda x: frontmatter.loads(x).to_dict() if isinstance(x, str) else x))
    filepath = field(default=None, converter=optional(Path)) 
    
    def __str__(self):
        return self.content

    def __getattr__(self, attr):
        return self.metadata.get(attr, None) 
    
    def asdict(self, *atts):
        if len(atts) == 0:
            return attr.asdict(self) 
        else:
            return attr.asdict(self, filter=lambda x: x in atts)


    @classmethod 
    def read_kwargs(cls, **kwargs):
        metadata = kwargs.get('metadata', {})
        for key, value in kwargs.items():
            if key not in ('content', 'metadata', 'filepath'):
                metadata[key] = str(value)
        return cls(filepath=kwargs['filepath'], content=kwargs['content'], metadata=metadata)

    
    
    @classmethod 
    def read_text(cls, text):
        try:
            metadata, content = frontmatter.parse(text)
        except Exception as e:
            raise e
        if len(metadata) > 0:
            return cls(content=content, metadata=metadata) 
        else:
            return cls(content=content) 

    @classmethod 
    def read_args(cls, kwargs):
        filepath = kwargs.pop('filepath') 
        content = kwargs.pop('content', None) 
        return cls(filepath=filepath, content=content, metadata=kwargs)

    @classmethod
    def read_file(cls, filepath):
        fp = Path(filepath)
        
        if not fp.exists():
            raise FileNotFoundError(filepath)
        elif fp.suffix not in ('.md', '.markdown'):
            raise ValueError(f'{filepath} is not a document') 
        else:
            try:
                metadata, content = frontmatter.parse(fp.read_text())
            except Exception as e:
                raise e
            if len(metadata) > 0:
                return cls(content=content, metadata=metadata, filepath=filepath) 
            else:
                return cls(content=content, filepath=filepath) 

    def write_file(self, filepath=None, overwrite=None):
        try:
            fp = Path(filepath or self.filepath)
        except TypeError:
            raise TypeError('No filepath defined') 
        if fp.exists() and not overwrite:
            raise FileExistsError(f'{fp} exists and overwrite not permitted') 
        if self.metadata:
            doc = frontmatter.Post(self.content, **self.metadata)
        else:
            doc = frontmatter.Post(self.content, name=title_case(fp.stem), status='new')
        try:
            frontmatter.dump(doc, fp) 
        except Exception as e:
            print(e) 
            return False
        return fp
    
    def words(self):
        return len(re.findall(r'\b\w+\b', self.content)) 
    
    def modified(self):
        return int(self.filepath.stat().st_mtime) 

    def comments(self): 
        return (c for c in re.findall(r'<!--(.*?)-->', self.content, re.DOTALL))
            
