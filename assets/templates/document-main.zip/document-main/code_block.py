import re
import yaml

def extract_yaml_from_markdown(file_path):
    """
    Extracts a YAML code block from a Markdown file.
    
    Args:
        file_path (str): Path to the Markdown file.
    
    Returns:
        tuple: (dict containing YAML data, str with Markdown content without YAML block)
    """
    with open(file_path, "r", encoding="utf-8") as file:
        content = file.read()
    
    # Improved regex pattern to match a YAML code block more robustly
    pattern = r"```yaml\n(.*?)\n```"
    match = re.search(pattern, content, re.DOTALL | re.MULTILINE)
    
    yaml_data = {}
    if match:
        yaml_text = match.group(1).strip()
        try:
            yaml_data = yaml.safe_load(yaml_text)  # Parse YAML content
        except yaml.YAMLError:
            pass  # Return empty dict if YAML parsing fails
        
        # Remove the matched YAML block from the content
        content = re.sub(pattern, "", content, count=1).strip()
    
    return yaml_data, content

def insert_yaml_to_markdown(yaml_dict, markdown_content):
    """
    Inserts a dictionary as a YAML code block at the head of a Markdown document.
    
    Args:
        yaml_dict (dict): Dictionary to be converted into YAML.
        markdown_content (str): The original Markdown content.
    
    Returns:
        str: Updated Markdown content with the YAML block inserted at the beginning.
    """
    yaml_block = f"```yaml\n{yaml.safe_dump(yaml_dict, default_flow_style=False).strip()}\n```\n\n"
    return yaml_block + markdown_content.strip()

# Example usage:
# yaml_dict, markdown_content = extract_yaml_from_markdown("your_markdown.md")
# updated_markdown = insert_yaml_to_markdown(yaml_dict, markdown_content)
# print(updated_markdown)
