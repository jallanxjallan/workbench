#!/home/jeremy/Python3.12Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>
from pathlib import Path
from googleapiclient.http import MediaIoBaseUpload
from .drive_service import get_drive_service, MARKDOWN_MIME_TYPE, GOOGLE_DOCS_MIME_TYPE

def upload_markdown(file_path, drive_folder_id=None, filename=None, convert_to_gdocs=True):
    """Uploads a Markdown file to Google Drive, optionally converting to Google Docs.

    Args:
        drive_service: The Drive service object.
        file_path: The local path to the Markdown file.
        drive_folder_id: (Optional) The ID of the Drive folder to upload to.
        convert_to_gdocs: (Optional) Whether to convert the file to Google Docs. Defaults to True.

    Returns:
        The ID of the uploaded file on Drive, or None on error.
    """
    drive_service = get_drive_service()
    file_name = filename or file_path.stem
    mime_type = GOOGLE_DOCS_MIME_TYPE if convert_to_gdocs else MARKDOWN_MIME_TYPE # Default is Markdown.
    
    metadata = {'name': file_name, 'mimeType': mime_type}
    if drive_folder_id:
        metadata['parents'] = [drive_folder_id]

    try:
        with file_path.open('rb') as fh:
            media = MediaIoBaseUpload(fh, mimetype=MARKDOWN_MIME_TYPE, resumable=True) #Upload as markdown regardless of conversion
            file = drive_service.files().create(body=metadata, media_body=media, fields='id').execute()
            file_id = file.get('id')

            if convert_to_gdocs: #Convert to Google Docs
                convert_metadata = {'mimeType': GOOGLE_DOCS_MIME_TYPE}
                converted_file = drive_service.files().update(fileId=file.get('id'), body=convert_metadata).execute()
                converted_file = drive_service.files().get(fileId=file_id, fields='webViewLink').execute()
                file_link = converted_file.get('webViewLink')
                print(f"File converted to Google Docs. Link: {file_link}")
                return file_link
            else:
                print(f"File uploaded as Markdown. ID: {file.get('id')}")
                return file.get('id')

    except Exception as e:
        print(f"An error occurred: {e}")
        return None

