#!/home/jeremy/Python3.12Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

import io
from pathlib import Path
from googleapiclient.http import MediaIoBaseDownload
from .drive_service import get_drive_service

import os
import fire
import io
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
from google.oauth2 import service_account

SCOPES = ['https://www.googleapis.com/auth/drive']
SERVICE_ACCOUNT_FILE = 'credentials.json'  # Replace with your service account JSON file


def authenticate():
    """Authenticate using a service account and return a Drive API service object."""
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES
    )
    service = build('drive', 'v3', credentials=creds)
    return service


def list_files(folder_id):
    """List all file IDs and names in a Google Drive folder."""
    service = authenticate()
    query = f"'{folder_id}' in parents and trashed=false"
    results = service.files().list(q=query, fields="files(id, name)").execute()
    files = results.get('files', [])
    return files


def download_files(folder_id, destination_folder='downloads'):
    """Download all files from a Google Drive folder."""
    service = authenticate()
    files = list_files(folder_id)

    if not files:
        print("No files found in the folder.")
        return

    os.makedirs(destination_folder, exist_ok=True)

    for file in files:
        file_id = file['id']
        file_name = file['name']
        request = service.files().get_media(fileId=file_id)
        file_path = os.path.join(destination_folder, file_name)

        with io.FileIO(file_path, 'wb') as fh:
            downloader = MediaIoBaseDownload(fh, request)
            done = False
            while not done:
                _, done = downloader.next_chunk()

        print(f"Downloaded: {file_name} to {file_path}")


if __name__ == "__main__":
    fire.Fire(list_files)


