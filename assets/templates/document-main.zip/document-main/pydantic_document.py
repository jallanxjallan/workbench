from __future__ import annotations
from pathlib import Path
from typing import Optional, Union, Dict, Any, List
import re
from datetime import datetime

import frontmatter
from pydantic import BaseModel, Field, field_validator, model_serializer, ValidationError, ConfigDict

from utility import title_case


class Document(BaseModel):
    """
    Wrapper for Markdown + frontmatter files.
    Handles loading, serialization, and introspection of document content and metadata.
    """
    model_config = ConfigDict(arbitrary_types_allowed=True)

    content: Optional[str] = Field(default=None)
    metadata: Dict[str, Any] = Field(default_factory=dict)
    filepath: Optional[Path] = Field(default=None)

    @field_validator("content", mode="before")
    def _coerce_content(cls, v: Any) -> Optional[str]:
        if v is None:
            return None
        if isinstance(v, list):
            return "\n\n".join(v)
        return str(v)

    @field_validator("metadata", mode="before")
    def _coerce_metadata(cls, v: Any) -> Dict[str, Any]:
        if v is None:
            return {}

        if isinstance(v, str):
            # 1) auto-fix missing space after any key colon
            fixed = re.sub(
                r"^([A-Za-z0-9_-]+):(\S)",
                r"\1: \2",
                v,
                flags=re.MULTILINE,
            )
            # 2) parse frontmatter from the cleaned text
            post = frontmatter.loads(fixed)
            return post.metadata

        # already a dict
        return v

    @field_validator("filepath", mode="before")
    def _coerce_filepath(cls, v: Any) -> Optional[Path]:
        if v is None:
            return None
        return Path(v).expanduser().resolve(strict=False)

    @model_serializer("filepath")
    def _serialize_filepath(self, v: Optional[Path], _info) -> Optional[str]:
        return str(v) if v is not None else None

    def __str__(self) -> str:
        return self.content or ""

    def __getattr__(self, attr: str) -> Any:
        # fall back to metadata lookup, return None if missing
        return self.metadata.get(attr, None)

    def asdict(self, *atts: str) -> Dict[str, Any]:
        data = self.model_dump()
        if atts:
            return {k: data[k] for k in atts if k in data}
        return data

    @classmethod
    def read_text(cls, text: str) -> Document:
        try:
            post = frontmatter.loads(text)
            return cls(content=post.content, metadata=post.metadata)
        except Exception as e:
            raise ValueError(f"Failed to parse markdown: {e}")

    @classmethod
    def read_file(cls, filepath: Union[str, Path]) -> Document:
        fp = Path(filepath)
        if not fp.exists():
            raise FileNotFoundError(f"{filepath} does not exist.")
        if fp.suffix.lower() not in (".md", ".markdown"):
            raise ValueError(f"{filepath} is not a markdown document.")
        try:
            post = frontmatter.load(fp)
            return cls(content=post.content, metadata=post.metadata, filepath=fp)
        except Exception as e:
            raise ValueError(f"Failed to load file: {e}")

    @classmethod
    def read_kwargs(cls, **kwargs: Any) -> Document:
        metadata = kwargs.pop("metadata", {}) or {}
        content = kwargs.pop("content", None)
        filepath = kwargs.pop("filepath", None)
        # any other kwargs become metadata entries
        for k, v in kwargs.items():
            metadata[k] = str(v)
        return cls(content=content, metadata=metadata, filepath=filepath)

    def write_file(
        self,
        filepath: Optional[Union[str, Path]] = None,
        overwrite: bool = False
    ) -> Path:
        fp = Path(filepath or self.filepath) if (filepath or self.filepath) else None
        if not fp:
            raise ValueError("No output path specified.")
        if fp.exists() and not overwrite:
            raise FileExistsError(f"{fp} exists and overwrite not permitted.")
        meta = self.metadata or {
            "name": title_case(fp.stem),
            "status": "new",
        }
        try:
            post = frontmatter.Post(self.content, **meta)
            frontmatter.dump(post, fp)
            return fp
        except Exception as e:
            raise IOError(f"Failed to write file: {e}")

    def write_text(self) -> str:
        try:
            post = frontmatter.Post(self.content, **self.metadata)
            return frontmatter.dumps(post)
        except Exception as e:
            raise IOError(f"Failed to write text: {e}")

    def words(self) -> int:
        return len(re.findall(r"\b\w+\b", self.content or ""))

    def modified(self) -> Optional[int]:
        if self.filepath and self.filepath.exists():
            return int(self.filepath.stat().st_mtime)
        return None

    def comments(self) -> List[str]:
        return re.findall(r"<!--(.*?)-->", self.content or "", re.DOTALL)

    def get(self, key: str, default: Any = None) -> Any:
        return self.metadata.get(key, default)

    def has_metadata(self, key: str) -> bool:
        return key in self.metadata

    # --- New JSON serialization methods ---
    def to_json(self) -> str:
        """
        Serialize this Document instance to a JSON string.
        """
        return self.model_dump_json()

    @classmethod
    def from_json(cls, json_str: str) -> Document:
        """
        Deserialize a JSON string back into a Document instance.
        """
        try:
            return cls.model_validate_json(json_str)
        except ValidationError as e:
            raise ValueError(f"Failed to parse JSON: {e}")
