#!/home/jeremy/Python3.12Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

from googleapiclient.errors import HttpError
from googleapiclient.http import MediaIoBaseUpload


# Constants
MARKDOWN_MIME_TYPE = "text/markdown"
GOOGLE_DOCS_MIME_TYPE = "application/vnd.google-apps.document"

def upload_or_update_file(drive_service, file_path, filename, drive_folder_id, convert_to_gdocs=True, existing_file_id=None, overwrite=False):
    metadata = {
			'name': filename,
            'parents': drive_folder_id,
			'mimeType': MARKDOWN_MIME_TYPE
    }
    try:
        if existing_file_id:
            # Check if the file ID exists in Google Drive
            try:
                existing_file = drive_service.files().get(fileId=existing_file_id, fields='name, mimeType').execute()
                print(f"File with ID {existing_file_id} already exists: {existing_file['name']} ({existing_file['mimeType']})")

                if overwrite:
                    print("Operation cancelled. No changes made.")
                    return
                else:
                    print("Overwriting the existing file...")

            except HttpError as error:
                # File ID not found
                if error.resp.status == 404:
                    print(f"No file found with ID {existing_file_id}. Proceeding to create a new file.")
                else:
                    raise error

        # Open the file for upload
        with file_path.open('rb') as fh:
            media = MediaIoBaseUpload(fh, mimetype=MARKDOWN_MIME_TYPE, resumable=True)

            if existing_file_id:
                # Update the existing file
                updated_file = drive_service.files().update(
                    fileId=existing_file_id, 
                    media_body=media,
                    body=metadata
                ).execute()
                print(f"File updated successfully. ID: {updated_file.get('id')}")

            else:
                # Create a new file
                new_file = drive_service.files().create(
                    body=metadata, 
                    media_body=media, 
                    fields='id'
                ).execute()
                existing_file_id = new_file.get('id')
                print(f"New file created successfully. ID: {existing_file_id}")

        # Convert to Google Docs if required
        if convert_to_gdocs:
            convert_metadata = {'mimeType': GOOGLE_DOCS_MIME_TYPE}
            converted_file = drive_service.files().update(fileId=existing_file_id, body=convert_metadata).execute()
            converted_file = drive_service.files().get(fileId=existing_file_id, fields='webViewLink').execute()
            file_link = converted_file.get('webViewLink')
            print(f"File converted to Google Docs. Link: {file_link}")

    except HttpError as error:
        print(f"An error occurred: {error}")


def list_file_versions(drive_service, file_id):
    """List the version history of a file."""
    try:
        print(f"Fetching version history for file ID: {file_id}")
        revisions = drive_service.revisions().list(fileId=file_id).execute()
        if 'revisions' not in revisions:
            print("No revisions found for this file.")
            return

        print("Version History:")
        for revision in revisions['revisions']:
            print(f"- Revision ID: {revision['id']}, Modified Time: {revision['modifiedTime']}, Keep Forever: {revision.get('keepForever', False)}")
    except HttpError as error:
        print(f"An error occurred while fetching version history: {error}")


def delete_file_version(drive_service, file_id, revision_id):
    """Delete a specific version of a file."""
    try:
        print(f"Deleting revision {revision_id} for file ID: {file_id}")
        drive_service.revisions().delete(fileId=file_id, revisionId=revision_id).execute()
        print(f"Revision {revision_id} deleted successfully.")
    except HttpError as error:
        print(f"An error occurred while deleting revision {revision_id}: {error}")
