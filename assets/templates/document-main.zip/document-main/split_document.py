from document import Document 
import regex

def split_document(filepath):
    doc = Document.read_file(filepath)
    for part in regex.split(r'-{6}', doc.content):
        sub_text = part.replace('```yaml', '---').replace('```', '---')
        yield Document.read_text(sub_text)
        