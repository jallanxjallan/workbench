#!/home/jeremy/Python3.12Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>
from googleapiclient.discovery import build
from google.oauth2 import service_account

# If modifying these scopes, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/drive']

# Path to your service account key file. Download this from your Google Cloud Console.
SERVICE_ACCOUNT_FILE = '/home/jeremy/Library/document/gdrivefileaccess-447907-3441c650fa37.json' # CHANGE THIS
SERVICE_ACCOUNT_EMAIL = 'https://console.cloud.google.com/iam-admin/serviceaccounts/details/112954817051736383053?project=gdrivefileaccess-447907'

# Drive MIME types for Markdown
MARKDOWN_MIME_TYPE = 'text/markdown'
GOOGLE_DOCS_MIME_TYPE = 'application/vnd.google-apps.document'

def get_drive_service():
    """Authenticates and returns the Drive service."""
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)
    return build('drive', 'v3', credentials=creds)
