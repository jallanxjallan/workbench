#!/home/jeremy/Python3.12Env/bin/python
# -*- coding: utf-8 -*-
#
#  module.py
#
#  Copyright 2019 Jeremy Allan <jeremy@jeremyallan.com>

import io
from pathlib import Path
from googleapiclient.http import MediaIoBaseDownload
from .drive_service import get_drive_service

def download_markdown(drive_service, file_id, local_path):
    """Downloads a Markdown file from Google Drive.

    Args:
        drive_service: The Drive service object.
        file_id: The ID of the file on Drive.
        local_path: The local path to save the downloaded file.
    """
    
    try:
        request = drive_service.files().get_media(fileId=file_id)
        fh = io.FileIO(local_path, 'wb')
        downloader = MediaIoBaseDownload(fh, request)
        done = False
        while done is False:
            status, done = downloader.next_chunk()
            print(f"Download Progress: {int(status.progress() * 100)}%.")
        print(f"File downloaded to {local_path}")
    except Exception as e:
        print(f"An error occurred: {e}")

def convert_gdocs_to_markdown_and_download(drive_service, file_id, local_path):
    """Converts a Google Doc to Markdown and downloads it.

    Args:
        drive_service: The Drive service object.
        file_id: The ID of the Google Doc on Drive.
        local_path: The local path to save the downloaded Markdown file.
    """
    try:
      request = drive_service.files().export_media(fileId=file_id, mimeType='text/markdown')
      with Path(local_path).open('wb') as fh:
          downloader = MediaIoBaseDownload(fh, request)
      done = False
      while done is False:
          status, done = downloader.next_chunk()
          print(f"Download Progress: {int(status.progress() * 100)}%.")
      print(f"File downloaded to {local_path}")
    except Exception as e:
        print(f"An error occurred: {e}")

